#!/bin/bash


docker build -t npe .
