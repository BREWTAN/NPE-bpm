export SCALA_HOME=/opt/soft/scala-$SCALA_VER
export SBT_HOME=/opt/soft/sbt
export ACT_HOME=/opt/soft/activator-$ACTIVATOR_VER

export PATH=$PATH:$SCALA_HOME/bin:$SBT_HOME/bin:$ACT_HOME/
